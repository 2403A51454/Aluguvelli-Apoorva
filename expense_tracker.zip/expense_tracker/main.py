from database import create_table, add_expense, get_all_expenses
from datetime import datetime

def show_menu():
    print("\n--- Personal Expense Tracker ---")
    print("1. Add Expense")
    print("2. View All Expenses")
    print("3. Show Total Expense")
    print("4. Exit")

def add_new_expense():
    date = input("Enter date (YYYY-MM-DD) or press Enter for today: ")
    if date == "":
        date = datetime.now().strftime("%Y-%m-%d")

    category = input("Enter category (Food, Travel, Rent, etc.): ")
    amount = float(input("Enter amount: "))
    description = input("Enter description: ")

    add_expense(date, category, amount, description)
    print("Expense added successfully!")

def view_expenses():
    expenses = get_all_expenses()
    if not expenses:
        print("No expenses found.")
        return

    print("\nID | Date | Category | Amount | Description")
    print("---------------------------------------------")
    for e in expenses:
        print(f"{e[0]} | {e[1]} | {e[2]} | {e[3]} | {e[4]}")

def show_total():
    expenses = get_all_expenses()
    total = sum(e[3] for e in expenses)
    print(f"\nTotal Expense: ₹{total}")

def main():
    create_table()

    while True:
        show_menu()
        choice = input("Choose an option: ")

        if choice == "1":
            add_new_expense()
        elif choice == "2":
            view_expenses()
        elif choice == "3":
            show_total()
        elif choice == "4":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()